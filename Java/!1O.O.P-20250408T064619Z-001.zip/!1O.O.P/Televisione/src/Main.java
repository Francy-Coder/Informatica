/*Progettare e implementare una classe Televisione in java, che modelli il comportamento di una televisione. La televisione ha i seguenti attributi:
- Stato (accesa/spenta).
- Volume (un valore intero compreso tra 0 e 10).
- Canale (un valore intero compreso tra 0 e 99).
- Modalità silenziosa (attiva/disattiva).

Implementare un costruttore per inizializzare lo stato della televisione e i seguenti metodi:
- pulsanteRosso(): accende o spegne la televisione.
- canaleSuccessivo(): cambia il canale al successivo (se la TV è accesa).
- canalePrecedente(): cambia il canale al precedente (se la TV è accesa).
- aumentaVolume(): incrementa il volume (se la TV è accesa e non è in modalità silenziosa).
- abbassaVolume(): decrementa il volume (se la TV è accesa e non è in modalità silenziosa).
- impostaCanale(int c): imposta il canale a un valore specifico (se la TV è accesa e il valore è compreso tra 0 e 99).
- print(): stampa lo stato attuale della televisione (accesa/spenta, canale corrente, volume, stato del silenzioso).
- pulsanteSilenzioso(): attiva o disattiva la modalità silenziosa (se la TV è accesa).
Si segua il principio di incapsulamento della programmazione orientata agli oggetti.
Infine, creare una classe di Main per verificare il corretto funzionamento dell'oggetto Televisore.*/

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Televisione tv = new Televisione();

        String parole;
        int valore;
        int scelta, comando = 1;

        System.out.println("Ricordarsi di accendere la televisione se si vuole modificare qualcosa.");
        do {
            System.out.println("\nCosa vuoi fare? \n1. pulsanteRosso \n2. canaleSuccesivo \n3. canalePrecedente \n4. aumentaVolume \n5. abbasaVolume \n6. impostaCanale \n7. modalitaSilenziosa \n8. stampa \n9. esci");
            scelta = sc.nextInt();
            switch (scelta) {
                case 1:
                    System.out.println("\nVuoi accendere o spegnere la televisone? ");
                    parole = sc.next();
                    tv.pulsanteRosso(parole);
                    break;

                case 2:
                    System.out.println("\nIl canale è stato aumentato di uno.");
                    tv.canaleSuccessivo();
                    break;

                case 3:
                    System.out.println("\nIl canale è stato diminuito di uno.");
                    tv.canalePrecedente();
                    break;

                case 4:
                    System.out.println("\nIl volume è stato aumentato di uno.");
                    tv.aumentaVolume();
                    break;

                case 5:
                    System.out.println("\nIl volume è stato diminuito di uno");
                    tv.abbassaVolume();
                    break;

                case 6:
                    System.out.println("\nInserisci il numero del canale (0-99): ");
                    valore = sc.nextInt();
                    tv.impostaCanale(valore);
                    break;

                case 7:
                    System.out.println("\nVuoi attivare o disattivare la modalità silenziosa? ");
                    parole = sc.next();
                    tv.modalitaSilenziosa(parole);
                    break;

                case 8:
                    tv.stampa();
                    break;

                case 9:
                    comando = 0;
                    System.out.println("\nArrivederci");
                    break;

                default:
                    System.out.println("\nDevi scegliere un numero tra 1 e 9.");
            }
        }while(comando != 0);
    }
}
