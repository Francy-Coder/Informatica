public class Televisione {
    String stato, modalitaSilenziosa;
    int volume, canale;

    public Televisione () {
        this.stato = "spenta";
        this.volume = 10;
        this.canale = 1;
        this.modalitaSilenziosa = "spenta";
    }

    public void pulsanteRosso (String parole) {
        if (parole.equals("accendere")) {
            stato = "acceso";
        } else if (stato.equals("spegnere")) {
            stato = "spento";
        }
    }

    public void canaleSuccessivo(){
        if(stato.equals("acceso")){
            if (canale > 0 && canale < 99)
                canale++;
        }
    }

    public void canalePrecedente(){
        if(stato.equals("acceso")) {
            if (canale > 0 && canale < 99)
                canale--;
        }
    }

    public void aumentaVolume(){
        if(stato.equals("acceso")){
            if (modalitaSilenziosa.equals("spenta"))
                volume++;
        }
    }

    public void abbassaVolume(){
        if(stato.equals("acceso")){
            if (modalitaSilenziosa.equals("spenta"))
                volume--;
        }
    }

    public void impostaCanale(int valore){
        if(stato.equals("acceso")) {
            if (valore > 0 && valore < 99)
                canale = valore;
        }
    }

    public void modalitaSilenziosa (String parole){
        if (parole.equals("attivare")) {
            modalitaSilenziosa = "accesa";
        } else if (parole.equals("disattivare")) {
            modalitaSilenziosa = "spenta";
        }
    }

    public void stampa(){
        System.out.println("\nStato: " + stato + "\nVolume: " + volume + "\nCanale: " + canale + "\nModalitàSilenziosa: " + modalitaSilenziosa);
    }
}