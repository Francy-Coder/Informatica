/* Scrivere in Java la classe di nome Rubrica che offre le funzionalità di gestione di contatti. Le funzionalità sono:
- Inserimento nuovo contatto.
- Cancella contatto.
- Modifica contatto.
- Cerca contatto.

In Rubrica non ci possono essere due contatti con lo stesso numero di telefono.
 */

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int numeroContatti = 0;
        GesticiContatti[] cnt = new GesticiContatti[numeroContatti];

        boolean condizione = true;
        do{
            System.out.println("\nCosa vuoi fare? \n1. Inserisci nuovo contatto \n2. Cancella contatto \n3. Modifica contatto \n4. Cerca contatto \n5. Esci");
            int scelta = sc.nextInt();
            switch (scelta){
                case 1:
                    System.out.print("Nome: ");
                    String nome = sc.next();

                    System.out.print("Cognome: ");
                    String cognome = sc.next();

                    System.out.print("Numero di telefono: ");
                    int numeroTelefono = sc.nextInt();

                    GesticiContatti nuovoContatto = new GesticiContatti(nome, cognome, numeroTelefono);
                    cnt.aggiungiContatto(nuovoContatto);

                    break;

                case 2:
                    System.out.print("Inserisci il numero di telefono del contatto da eliminare: ");
                    int numeroDaEliminare = sc.nextInt();
                    cnt.cancellaContatto(numeroDaEliminare);

                    break;

                case 3:
                    System.out.print("Inserisci il numero di telefono del contatto da modificare: ");
                    int numeroDaModificare = sc.nextInt();

                    System.out.print("Inserisci il nuovo nome: ");
                    String nuovoNome = sc.next();

                    System.out.print("Inserisci il nuovo cognome: ");
                    String nuovoCognome = sc.next();

                    System.out.print("Inserisci il nuovo numero di telefono: ");
                    int nuovoNumero = sc.nextInt();
                    cnt.modificaContatto(numeroDaModificare, nuovoNome, nuovoCognome, nuovoNumero);
                    break;

                case 4:
                    System.out.print("Inserisci il numero di telefono del contatto da cercare: ");
                    int numeroDaCercare = sc.nextInt();

                    GesticiContatti contattoTrovato = cnt.cercaContatto(numeroDaCercare);
                    if (contattoTrovato != null) {
                        System.out.println("Il contatto è stato trovato:");
                        System.out.println("Nome: " + contattoTrovato.nome);
                        System.out.println("Cognome: " + contattoTrovato.cognome);
                        System.out.println("Numero di Telefono: " + contattoTrovato.numeroTelefono);
                    }
                    break;

                case 5:
                    condizione = false;
                    System.out.println("Arrivederci");
                    break;
                    
                default:
                    System.out.println("Devi scegliere tra 1 e 5.");
                    break;
            }
        }while (condizione);
    }
}