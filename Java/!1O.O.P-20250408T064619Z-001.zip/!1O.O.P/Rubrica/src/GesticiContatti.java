public class GesticiContatti {
    private String nome;
    private String cognome;
    private int numeroTelefono;

    public GesticiContatti(String nome, String cognome, int numeroTelefono) {
        this.nome = nome;
        this.cognome = cognome;
        this.numeroTelefono = numeroTelefono;
    }

    public void modificaContatto(int numeroTelefono, String nuovoNome, String nuovoCognome, int nuovoNumero) {
        for (GesticiContatti cnt : contatti) {
            if (cnt.numeroTelefono == numeroTelefono) {
                contatto.nome = nuovoNome;
                contatto.cognome = nuovoCognome;
                contatto.numeroTelefono = nuovoNumero;
                System.out.println("Contatto modificato.");
                return;
            }
        }
        System.out.println("Contatto non trovato.");
    }

    public GesticiContatti cercaContatto(int numeroTelefono) {
        for (GesticiContatti cnt : contatti) {
            if (cnt.numeroTelefono == numeroTelefono) {
                return cnt;
            }
        }
        return null;
    }

    public void stampaRubrica() {
        for (GesticiContatti cnt : contatti) {
            System.out.println(cnt.nome + " " + cnt.cognome + " - " + cnt.numeroTelefono);
        }
    }
}