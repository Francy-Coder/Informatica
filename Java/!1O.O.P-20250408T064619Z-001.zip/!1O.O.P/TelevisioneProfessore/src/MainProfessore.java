public class MainProfessore {
    public static void main(String[] args) {
        TelevisioneProfessore televisore = new TelevisioneProfessore(false, 0, 0, false);
        televisore.pulsanteRosso();
        System.out.println("stato: " + televisore.getCanale());
        televisore.canaleSuccesivo();
        System.out.println(televisore.getCanale());
        televisore.canaleSuccesivo();
        System.out.println(televisore.getCanale());
    }
}