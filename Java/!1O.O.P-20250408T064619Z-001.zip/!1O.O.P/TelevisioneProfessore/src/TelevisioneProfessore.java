/*
Attributi di classe:
- stato
- volume
- canale
- muto

Metodi
- pulsanteRosso() --> accende o spegne
- canaleSuccesivo() --> se acceso, cambia al canale succesivo (canale++)
- canalePredecente() --> se acceso, cambia al canale precedente (canale--)
- aumentaVolume() --> se acceso e non muto, volume++
- abbasaVolume() --> se acceso e non muto, volume--
- impostaCanale(int c) --> se acceso assegna nuova canale
- print() --> stampa a video tutti i valori degli attributi
- pulsanteSilenzio() --> se acceso, attiva o disattiva
 */

public class TelevisioneProfessore {
    public final int minVolume = 0; // <--- costante, una cosa che non cambia nel tempo. applicata in una variabile non puo piu essere piu modificata
    public final int maxVolume = 10;
    public final int minCanale = 0;
    public final int maxCanale = 99;

    private boolean stato;
    private int volume;
    private int canale;
    private boolean muto;

    public TelevisioneProfessore (boolean stato, int volume, int canale, boolean muto){
        this.stato = stato;
        this.volume = volume;
        this.canale = canale;
        this.muto = muto;
    }

    public void pulsanteRosso(){
        if (stato) stato = false;
        else stato = true;
    }

    public boolean getStato(){ return stato; }

    public void canaleSuccesivo(){
        if(stato)
            canale++;
        if(canale > maxCanale) canale = 0;
    }

    public void canalePrecedente(){
        if(stato)
            canale--;
        if(canale < minCanale) canale = 99;
    }

    public int getCanale(){ return canale; }

    public void aumentaVolume(){
        //...
    }

    public void abbassaVolume(){
        //...
    }

    public void print(){
        //...
    }

    public void pulsanteSilenzio(){
        //...
    }
}
