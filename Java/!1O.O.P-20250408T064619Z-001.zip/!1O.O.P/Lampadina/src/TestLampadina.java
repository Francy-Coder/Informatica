/*Classi:
- Main (TestLampadina)
- Lampadina

Metodi:
- click()
- stato()

Attributi:
- accesa
- spenta
- rotta
*/

import java.util.Scanner;
public class TestLampadina{

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Quate lampadine vuoi usare?");
        int numeroLampadine = sc.nextInt();
        Lampadina[] listaL = new Lampadina[numeroLampadine];

        for (int i = 0; i < numeroLampadine; i++) {
            int numeroCasuale = (int) (Math.random()*10+1);
            listaL[i] = new Lampadina(numeroCasuale);
        }

        int scelta, condizone = 0, condizoneSeconda = 0;

        System.out.println("\nCosa vuoi fare: \n1. Vedi Lampadine \n2. Esci");
        scelta = sc.nextInt();
        do {
            switch (scelta) {
                case 1:
                    System.out.println("\nSceglia una lampdiana delle " + numeroLampadine + ": ");
                    int  sceltaLampadina = sc.nextInt();
                    if (sceltaLampadina <= numeroLampadine) {
                        System.out.println("\nCosa vuoi fare: \n1. Vedi lo stato della lampadina \n2. Usa la lampadina \n3. Torna indietro");
                        int sceltaUso = sc.nextInt();
                        do {
                            switch (sceltaUso) {
                                case 1:
                                    System.out.println(listaL[sceltaLampadina - 1].getStato());
                                    condizoneSeconda = 1;
                                    break;

                                case 2:
                                    listaL[sceltaLampadina - 1].click();
                                    break;

                                case 3:
                                    condizoneSeconda = 1;
                                    break;
                            }
                        } while (condizoneSeconda != 1);
                    }else{
                        System.out.println("La lampadina non esiste");
                    }
                    break;

                case 2:
                    condizone = 1;
                    System.out.println("Arrivederci");
                    break;
            }
        } while (condizone != 1);
    }
}