public class Lampadina {
    private boolean stato;
    private int clicks;
    int resistenza;

    public Lampadina(int resistenza) {
        this.stato = false;
        this.clicks = 0;
        this.resistenza = resistenza;
    }

    public String getStato() {
        if(Rotta()){
            return "Rotta";
        } else if (stato) {
            return "Accesa";
        }else{
            return "Spenta";
        }
    }

    public void click() {
        clicks++;
        if (!Rotta())
            stato = !stato;
    }

    private boolean Rotta() {
        return clicks > resistenza;
    }
}