/* Caratteristiche:
nome, cognome e email
*/

public class GestisciPartecipanti {
    private String nomePartecipante;
    private String cognomePartecipante;
    private String emailPartecipante;

    public GestisciPartecipanti(String nomePartecipante, String cognomePartecipante, String emailPartecipante){
        this.nomePartecipante = nomePartecipante;
        this.cognomePartecipante = cognomePartecipante;
        this.emailPartecipante = emailPartecipante;
    }

    public String getNomePartecipante(){
        return nomePartecipante;
    }

    public void setNomePartecipante(String nomePartecipante) {
        this.nomePartecipante = nomePartecipante;
    }

    public String getCognomePartecipante(){
        return cognomePartecipante;
    }

    public void setCognomePartecipante(String cognomePartecipante) {
        this.cognomePartecipante = cognomePartecipante;
    }

    public String getEmailPartecipante() {
        return emailPartecipante;
    }

    public void setEmailPartecipante(String emailPartecipante) {
        this.emailPartecipante = emailPartecipante;
    }
}