/*Caratteristiche:
nome, tipo, codice e massimo persone
*/

public class GestisciEventi {
    private String nomeEvento;
    private String tipoEvento;
    private int codiceEvento;
    private int maxPersoneEvento;

    public GestisciEventi(String nomeEvento, String tipoEvento, int codiceEvento, int maxPersoneEvento){
        this.nomeEvento = nomeEvento;
        this.tipoEvento = tipoEvento;
        this.codiceEvento = codiceEvento;
        this.maxPersoneEvento = maxPersoneEvento;
    }

    public String getNomeEvento(){
        return nomeEvento;
    }

    public void setNomeEvento(String nomeEvento){
        this.nomeEvento = nomeEvento;
    }

    public String getTipoEvento(){
        return tipoEvento;
    }

    public void setTipoEvento(String tipoEvento){
        this.tipoEvento = tipoEvento;
    }

    public int getCodiceEvento(){
        return codiceEvento;
    }

    public void setCodiceEvento(int codiceEvento){
        this.codiceEvento = codiceEvento;
    }

    public int getMaxPersone(){
        return maxPersoneEvento;
    }

    public void setMaxPersone(int maxPersoneEvento){
        this.maxPersoneEvento = maxPersoneEvento;
    }
}
