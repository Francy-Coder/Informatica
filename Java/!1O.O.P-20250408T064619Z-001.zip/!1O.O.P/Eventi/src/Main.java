/*Consegnare il progetto e il programma in Java.

Immagina di dover creare un programma per gestire di Eventi (conferenza, festival, ecc.).
Avrai bisogno di due tipologie principali di dati: quelli relativi ai Partecipanti (nome, cognome e email) e quelli relativi alle attività dell'Evento (nome, tipo e codice).
Il programma dovrà dare la possibilità all'utente di creare gli Eventi, i Partecipanti e assegnargli l’Evento.
Attenzione: ogni Evento può contenere un numero massimo di Partecipanti.
Dall’Evento deve essere possibile recuperare l’elenco dei Partecipanti, e per un Partecipante modificare e  stampare le sue caratteristiche.

Classi
- Gestici Eventi
- Gestici Partecipanti

Cosa posso fare?
- Crea Evento
- Elimina Evento
- Modifica Evento

- Crea Partecipante + Assegna al Evento
- Elimina Partecipante  + Rimuovi dal evento
- Modifica Partecipante

- Stampa Partecipanti di un evento

Info:
- Un evento ha un max partecipanti
*/

import java.util.Scanner;

public class Main {
    static GestisciEventi[] listaE = new GestisciEventi[10];
    static GestisciPartecipanti[] listaP = new GestisciPartecipanti[100]; //???
    private static int numeroEventi = 0;
    private static int numeroPartecipanti = 0; //???

    public static String stampaEventi() {
        String s = "";
        if(numeroEventi == 0) {
            s = "Non ci sono eventi";
        }else{
            s = s + "Elenco degli eventi:\n";
            for(int i = 0; i < numeroEventi; i++){
                s = s + (i + 1) + ". " + "Nome: " + listaE[i].getNomeEvento() + " - Tipo: " + listaE[i].getTipoEvento() + " - Codice: " + listaE[i].getCodiceEvento() + "- Massimo Persone: " + listaE[i].getMaxPersone() + "\n";
            }
        }
        return s;
    }

    public static String stampaPartecipanti(String nomeEventoStampaPartecipanti) { //???
        String s = "";
        for (int i = 0; i < numeroEventi; i++) {
            if (listaE[i].getNomeEvento().equals(nomeEventoStampaPartecipanti)) {
                if (numeroPartecipanti == 0) {
                    s = "Non ci partecipanti";
                } else {
                    s = s + "Elenco dei partecipanti:\n";
                    for (int j = 0; j < numeroPartecipanti; j++) {
                        s = s + (j + 1) + ". " + "Nome: " + listaP[j].getNomePartecipante() + " - Cognome: " + listaP[j].getCognomePartecipante() + " - Email: " + listaP[j].getEmailPartecipante() + "\n";
                    }
                }
            }
        } return s;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int condizione = 0;

        do{
            System.out.println("\nCosa vuoi fare? \n1. Crea Evento \n2. Elimina Evento \n3. Modifica Evento \n4. Stampa Eventi \n5. Aggiungi Partecipante \n6. Elimina Partecipante \n7. Modifica Partecipante " +
                    "\n8. Stampa Partecipanti di un Evento \n9. Esci");
            int scelta = sc.nextInt();
            switch (scelta){
                case 1:
                    if(numeroEventi <= 10) {
                        System.out.println("Inserisci il nome del evento: ");
                        String nomeEvento = sc.next();

                        System.out.println("Inserisci il tipo del evento: ");
                        String tipoEvento = sc.next();

                        System.out.println("Inserisci la data del evento: ");
                        int codiceEvento = sc.nextInt();

                        System.out.println("Inserisci il massimo di persone: ");
                        int maxPersoneEvento = sc.nextInt();

                        listaE[numeroEventi] = new GestisciEventi(nomeEvento, tipoEvento, codiceEvento, maxPersoneEvento);
                        numeroEventi++;
                    }else{
                        System.out.println("Hai raggiunto il massimo degli eventi, elimina un evento per crearne di nuovi");
                    }
                    break;

                case 2:
                    System.out.println("Inserisci il nome dell'evento da eliminare: ");
                    String nomeEventoDaEliminare = sc.next();

                    boolean trovatoElimina = false;
                    for(int i = 0; i < numeroEventi; i++){
                        if (listaE[i].getNomeEvento().equals(nomeEventoDaEliminare)) {
                            for(int j = i; j < numeroEventi - 1; j++){
                                listaE[j] = listaE[j + 1];
                            }
                            numeroEventi--;
                            trovatoElimina = true;
                        }
                    }

                    if(trovatoElimina) {
                        System.out.println("L'evento da eliminare è stato trovato");
                    }else{
                        System.out.println("L'evento da eliminare non è stato trovato");
                    }
                    break;

                case 3:
                    System.out.println("Inserisci il nome del evento da modificare: ");
                    String nomeEventoDaModificare = sc.next();

                    boolean trovatoModifica = false;
                    for(int i = 0; i < numeroEventi; i++) {
                        if(listaE[i].getNomeEvento().equals(nomeEventoDaModificare)) {
                            System.out.println("Cosa vuoi modificare: \n1. Nome \n2. Tipo \n3. Codice \n4. Massimo Persone");
                            int sceltaModifica = sc.nextInt();
                            switch (sceltaModifica){
                                case 1:
                                    System.out.println("Inserisci il nuovo nome del evento: ");
                                    String nomeEventoNuovo = sc.next();
                                    listaE[i].setNomeEvento(nomeEventoNuovo);
                                    break;

                                case 2:
                                    System.out.println("Inserisci il nuovo tipo del evento: ");
                                    String tipoEventoNuovo = sc.next();
                                    listaE[i].setTipoEvento(tipoEventoNuovo);
                                    break;

                                case 3:
                                    System.out.println("Inserisci il nuovo codice del evento: ");
                                    int codiceEventoNuovo = sc.nextInt();
                                    listaE[i].setCodiceEvento(codiceEventoNuovo);
                                    break;

                                case 4:
                                    System.out.println("Inserisci il nuovo massimo di persone: ");
                                    int maxPersoneEventoNuovo = sc.nextInt();
                                    listaE[i].setMaxPersone(maxPersoneEventoNuovo);
                                    break;
                            }
                        }
                    }

                    if(!trovatoModifica){
                        System.out.println("L'evento non è stato trovato");
                    }
                    break;

                case 4:
                    System.out.println(stampaEventi());
                    break;

                case 5: //???
                    System.out.println("In quale evento vuoi aggiungere il partecipante: ");
                    String nomeEventoPartecipante = sc.next();

                    for(int i = 0; i < numeroEventi; i++) {
                        if (listaE[i].getNomeEvento().equals(nomeEventoPartecipante)) {
                            if(listaE[i].getMaxPersone() <= numeroPartecipanti){
                                System.out.println("Inserisci il nome del partecipante: ");
                                String nomePartecipante = sc.next();

                                System.out.println("Inserisci il cognome del partecipaante: ");
                                String cognomePartecipante = sc.next();

                                System.out.println("Inserisci l'email del partecipante: ");
                                String emailPartecipante = sc.next();

                                listaP[i] = new GestisciPartecipanti(nomePartecipante, cognomePartecipante, emailPartecipante);
                                numeroPartecipanti++;
                            }else{
                                System.out.println("Hai raggiunto il massimo di partecipanti, modifica l'evento per aumentare il numero di partecipanti");
                            }
                        }
                    }
                    break;

                case 6: //???
                    System.out.println("Inserisci il nome del evento in cui si trova il partecipante da eliminare: ");
                    String nomeEventoPartecipanteDaEliminare = sc.next();

                    boolean trovatoEventoPartecipanteElimina = false;
                    for(int i = 0; i < numeroEventi; i++){
                        if(listaE[i].getNomeEvento().equals(nomeEventoPartecipanteDaEliminare)){
                            System.out.println("Inserisci il nome del partecipante da eliminare: ");
                            String nomePartecipanteElimina = sc.next();

                                if(listaP[i].getNomePartecipante().equals(nomePartecipanteElimina)){

                            }
                        }
                        numeroPartecipanti--;
                    }
                    if(!trovatoEventoPartecipanteElimina)
                        System.out.println("L'evento con il partecipante da eliminare nonè stato trovato");
                    break;

                case 7: //???
                    System.out.println("Inserisci il nome del evento in cui si trova il partecipante da modificare: ");
                    String nomeEventoPartecipanteModifica = sc.next();

                    boolean trovatoEventoPartecipanteModifica = false;
                    for(int i = 0; i < numeroEventi; i++){
                        if(listaE[i].getNomeEvento().equals(nomeEventoPartecipanteModifica)){
                            System.out.println("Inserisci il nome del partecipante da modificare: ");
                            String nomePartecipanteElimina = sc.next();

                            if(listaP[i].getNomePartecipante().equals(nomePartecipanteElimina)){
                                System.out.println("Cosa vuoi modificare: \n1.Nome \n2. Cognome \n3. Email");
                                int sceltaModifica = sc.nextInt();
                                switch (sceltaModifica){
                                    case 1:
                                        System.out.println("Inserisci il nuovo nome del partecipante: ");
                                        String nomePartecipanteNuovo = sc.next();
                                        listaP[i].setNomePartecipante(nomePartecipanteNuovo);
                                        break;

                                    case 2:
                                        System.out.println("Inserisci il nuovo cognome del partecipante: ");
                                        String congomePartecipanteNuovo = sc.next();
                                        listaP[i].setCognomePartecipante(congomePartecipanteNuovo);
                                        break;

                                    case 3:
                                        System.out.println("Inserisci la nuova email del partecipante: ");
                                        String emailPartecipanteNuova = sc.next();
                                        listaP[i].setEmailPartecipante(emailPartecipanteNuova);
                                        break;
                                }
                            }
                        }
                    }
                    if(!trovatoEventoPartecipanteModifica)
                        System.out.println("L'evento con il partecipante da eliminare nonè stato trovato");
                    break;

                case 8: //???
                    System.out.println("Inserisci il nome del evento di cui vedere i partecipanti: ");
                    String nomeEventoStampaPartecipanti = sc.next();
                    stampaPartecipanti(nomeEventoStampaPartecipanti);
                    break;

                case 9:
                    condizione = 1;
                    System.out.println("Arrivederci");
                    break;
            }
        }while(condizione != 1);
    }
}