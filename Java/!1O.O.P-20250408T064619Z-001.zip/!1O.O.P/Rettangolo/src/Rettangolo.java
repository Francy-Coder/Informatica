//Si crei una classe rettangolo per memorizzare rettangoli e calcolarne perimetro e area.

public class Rettangolo {
    int altezza, lunghezza;
    int perimetro, area;

    public Rettangolo (int altezza, int lunghezza){
        this.altezza = altezza;
        this.lunghezza = lunghezza;
    }

    public void calcolo(){
        perimetro = 2*(altezza + lunghezza);

        area = lunghezza* altezza;
    }
    public void stampa(){
        System.out.println("perimetro: " + perimetro
                            + "\narea: " + area);
    }
}
