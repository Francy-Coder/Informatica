/*Si crei una classe rettangolo per memorizzare rettangoli e calcolarne perimetro e area.
Creare poi un programma che sfruttando la classe, scrivere i perimetri e le aree di 10 rettangoli, il primo con lunghezze dei lati 1 e 2, il secondo con 2 e 3, il terzo con 3 e 4 e così via.*/

public class Main {
    public static void main(String[] args) {
        Rettangolo uno, due, tre, quattro, cinque, sei, sette, otto, nove, dieci;
        uno = new Rettangolo(1, 2);
        System.out.println("> Uno: ");
        uno.calcolo();
        uno.stampa();

        due = new Rettangolo(2, 3);
        System.out.println("\n> Due: ");
        due. calcolo();
        due.stampa();

        tre = new Rettangolo(3, 4);
        System.out.println("\n> Tre: ");
        tre.calcolo();
        tre.stampa();

        quattro = new Rettangolo(4, 5);
        System.out.println("\n> Quattro: ");
        quattro.calcolo();
        quattro.stampa();

        cinque = new Rettangolo(5, 6);
        System.out.println("\n> Cinque: ");
        cinque.calcolo();
        cinque.stampa();

        sei = new Rettangolo(6, 7);
        System.out.println("\n> Sei: ");
        sei.calcolo();
        sei.stampa();

        sette = new Rettangolo(7, 8);
        System.out.println("\n> Sette: ");
        sette.calcolo();
        sette.stampa();

        otto = new Rettangolo(8, 9);
        System.out.println("\n> Otto: ");
        otto.calcolo();
        otto.stampa();

        nove = new Rettangolo(9, 10);
        System.out.println("\n> Nove: ");
        nove.calcolo();
        nove.stampa();

        dieci = new Rettangolo(10, 11);
        System.out.println("\n> Dieci: ");
        dieci.calcolo();
        dieci.stampa();
    }
}