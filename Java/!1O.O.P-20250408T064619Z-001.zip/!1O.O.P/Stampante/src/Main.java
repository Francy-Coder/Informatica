/*ESERCIZIO STAMPANTE
Una stampante è caratterizzata dal livello di inchiostro delle singole cartucce Ciano - Magenta - Giallo - Nero, le cartucce non possono essere ricaricate ma sostituite, la stampante permette di:
- stampare.
- fare copie.
- verificare il livello di inchiostro di una cartuccia/e.
- cambio cartuccia.
Creare il programma di gestione della stampa in cui è possibile usarte le funzionalità sopra indicate.
Tendo conto che la stampa o copia può essere fatta in bianco o in nero e vine stimato che per ogni frase si consuma 1% di inchiostro (delle cartucce corrispondenti).

Ragionare su quali attributi e metodi sono presenti e sul codice dei metodi (in particolare si ragioni su come gestire le stampe soprattutto nel caso non ci sia inchiostro sufficiente).
Nella classe e un main creare un oggetto Stampate e il menù per gestire tutte le funzionalità della stampata.

Consegnare:
- progettazione delle classi.
- codice in java delle classi progettate.
PS: quando la stampate viene create le cartucce non sono correttamente installate.*/

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        GestioneStampante gs = new GestioneStampante(false);

        boolean condizione = true;
        int scelta, numeroCopie;
        String testo, sceltaColori;
        do {
            System.out.println("\nCosa vuoi fare: \n1. Stampare \n2. Fare Copie \n3. Verificare il livello di inchiostro di una cartuccia/e \n4. Cambiare cartuccia \n5. Controlla le cartuccie \n6. Esci");
            scelta = sc.nextInt();
            switch (scelta) {
                case 1:
                    System.out.println("Insersci il testo da stampare: ");
                    testo = sc.next(); //sc.nextLine();

                    System.out.println("Inserisci il colore con cui stampare: \nCiano \nMagenta \nGiallo \nNero");
                    sceltaColori = sc.next();
                    gs.stampare(testo, sceltaColori);
                    break;

                case 2:
                    System.out.println("Inserisici il testo di cui fare delle copie: ");
                    testo = sc.next(); //sc.nextLine();

                    System.out.println("Quante copie vuoi creare: ");
                    numeroCopie = sc.nextInt();

                    System.out.println("Inserisci il colore con cui stampare: \nCiano \nMagenta \nGiallo \nNero");
                    sceltaColori = sc.next();
                    gs.fareCopie(testo, numeroCopie, sceltaColori);
                    break;

                case 3:
                    gs.verificaInchiostro();
                    break;

                case 4:
                    System.out.println("Quale cartuccia vuoi cambiare: \nCiano \nMagenta \nGiallo \nNero");
                    sceltaColori= sc.next();
                    gs.cambiaCartuccia(sceltaColori);
                    break;

                case 5:
                    gs.CartuccieCorretamenteInstallate();
                    break;

                case 6:
                    System.out.println("Arrivederci");
                    condizione = false;
                    break;

                default:
                    System.out.println("Devi scegliere tra 1 e 6");
            }
        }while(condizione);
    }
}