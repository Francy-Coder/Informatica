/*Metodi:
- stampare.
- fare copie.
- verificare il livello di inchiostro di una cartuccia/e.
- cambio cartuccia.
- controlla cartuccie.
 */

public class GestioneStampante {
    Stampante sp = new Stampante(100, 100, 100, 100);

    private boolean cartuccieCorretamenteInstallate;

    public GestioneStampante(boolean cartuccieCorretamenteInstallate) {
        this.cartuccieCorretamenteInstallate = cartuccieCorretamenteInstallate;
    }

    public void stampare(String testo, String sceltaColori) {
        if (!cartuccieCorretamenteInstallate) {
            System.out.println("Controlla che le cartuccie siano inserite");
        }

        if (cartuccieCorretamenteInstallate) {
            if (sceltaColori.equals("Ciano"))
                if (sp.InchiostroCiano(0, 3) != 0){
                    sp.InchiostroCiano(1, 1);
                    System.out.println("Ecco il testo con il colore " + sceltaColori + ":" + "\n" + testo);
                }else{
                    System.out.println("L'inchiostro ciano è finito");
                }

            if (sceltaColori.equals("Magenta"))
                if (sp.InchiostroMagenta(0, 3) != 0){
                    sp.InchiostroMagenta(1, 1);
                    System.out.println("Ecco il testo con il colore " + sceltaColori + ":" + "\n" + testo);
                }else{
                    System.out.println("L'inchiostro magenta è finito");
                }

            if (sceltaColori.equals("Giallo"))
                if (sp.InchiostroGiallo(0, 3) != 0){
                    sp.InchiostroGiallo(1, 1);
                    System.out.println("Ecco il testo con il colore " + sceltaColori + ":" + "\n" + testo);
                }else{
                    System.out.println("L'inchiostro giallo è finito");
                }

            if (sceltaColori.equals("Nero"))
                if (sp.InchiostroNero(0, 3) != 0){
                    sp.InchiostroNero(1, 1);
                    System.out.println("Ecco il testo con il colore " + sceltaColori + ":" + "\n" + testo);
                }else{
                    System.out.println("L'inchiostro nero è finito");
                }
        }
    }

    public void fareCopie(String testo, int numeroCopie, String sceltaColori) {
        if (!cartuccieCorretamenteInstallate){
            System.out.println("Controlla che le cartuccie siano inserite");
        }

        if (cartuccieCorretamenteInstallate) {
            if (sceltaColori.equals("Ciano")) {
                if (sp.InchiostroCiano(0, 3) >= numeroCopie) {
                    sp.InchiostroCiano(numeroCopie, 1);
                    System.out.println("Ecco " + numeroCopie + " del testo in ciano: ");
                    for (int i = 0; i < numeroCopie; i++) {
                        System.out.println(testo);
                    }
                }else{
                    System.out.println("Diminuisci il numero di copie o cambia la cartuccia");
                }
            }

            if (sceltaColori.equals("Magenta")) {
                if (sp.InchiostroMagenta(0, 3) >= numeroCopie) {
                    sp.InchiostroMagenta(numeroCopie, 1);
                    System.out.println("Ecco " + numeroCopie + " del testo in magenta: ");
                    for (int i = 0; i < numeroCopie; i++) {
                        System.out.println(testo);
                    }
                }else{
                    System.out.println("Diminuisci il numero di copie o cambia la cartuccia");
                }
            }

            if (sceltaColori.equals("Giallo")) {
                if (sp.InchiostroGiallo(0, 3) >= numeroCopie) {
                    sp.InchiostroGiallo(numeroCopie, 1);
                    System.out.println("Ecco " + numeroCopie + " del testo in giallo: ");
                    for (int i = 0; i < numeroCopie; i++) {
                        System.out.println(testo);
                    }
                }else{
                    System.out.println("Diminuisci il numero di copie o cambia la cartuccia");
                }
            }

            if (sceltaColori.equals("Nero")) {
                if (sp.InchiostroNero(0, 3) >= numeroCopie) {
                    sp.InchiostroNero(numeroCopie, 1);
                    System.out.println("Ecco " + numeroCopie + " del testo in nero: ");
                    for (int i = 0; i < numeroCopie; i++) {
                        System.out.println(testo);
                    }
                }else{
                    System.out.println("Diminuisci il numero di copie o cambia la cartuccia");
                }
            }
        }
    }

    public void verificaInchiostro() {
        if (!cartuccieCorretamenteInstallate){
            System.out.println("Controlla che le cartuccie siano inserite");
        }

        if (cartuccieCorretamenteInstallate) {
            int stampa;
            stampa = sp.InchiostroCiano(0, 3);
            System.out.println("Cartuccia Ciano: " + stampa);

            stampa = sp.InchiostroMagenta(0, 3);
            System.out.println("Cartuccia Magenta: " + stampa);

            stampa = sp.InchiostroGiallo(0, 3);
            System.out.println("Cartuccia Giallo: " + stampa);

            stampa = sp.InchiostroNero(0, 3);
            System.out.println("Cartuccia Nero: " + stampa);
        }
    }

    public void cambiaCartuccia (String sceltaColori) {
        if (!cartuccieCorretamenteInstallate) {
            System.out.println("Controlla che le cartuccie siano inserite");
        }

        if (cartuccieCorretamenteInstallate) {
            if (sceltaColori.equals("Ciano"))
                sp.InchiostroCiano(0, 0);

            if (sceltaColori.equals("Magenta"))
                sp.InchiostroMagenta(0, 0);

            if (sceltaColori.equals("Giallo"))
                sp.InchiostroGiallo(0,  0);

            if (sceltaColori.equals("Nero"))
                sp.InchiostroNero(0, 0);
        }
    }

    public void CartuccieCorretamenteInstallate (){
        if (cartuccieCorretamenteInstallate){
            System.out.println("Le cartuccie sono gia installate corretemente");
        }else {
            this.cartuccieCorretamenteInstallate = true;
            System.out.println("Hai sistemato le cartuccie");
        }
    }
}