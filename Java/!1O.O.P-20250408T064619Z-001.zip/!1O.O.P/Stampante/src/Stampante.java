public class Stampante {

    private int inchiostroCiano;
    private int inchiostroMagenta;
    private int inchiostroGiallo;
    private int inchiostroNero;

    public Stampante(int inchiostroCiano, int inchiostroMagenta, int inchiostroGiallo, int inchiostroNero) {
        this.inchiostroCiano = inchiostroCiano;
        this.inchiostroMagenta = inchiostroMagenta;
        this.inchiostroGiallo = inchiostroGiallo;
        this.inchiostroNero = inchiostroNero;
    }

    public int InchiostroCiano(int utilizzo, int scelta) {
        if(scelta == 1)
            inchiostroCiano = inchiostroCiano - utilizzo;

        if(scelta == 0)
            inchiostroCiano = 100;

        return inchiostroCiano;
    }

    public int  InchiostroMagenta(int utilizzo, int scelta) {
        if(scelta == 1)
            inchiostroMagenta = inchiostroMagenta - utilizzo;

        if(scelta == 0)
            inchiostroMagenta = 100;

        return inchiostroMagenta;
    }

    public int InchiostroGiallo(int utilizzo, int scelta) {
        if(scelta == 1)
            inchiostroGiallo = inchiostroGiallo - utilizzo;

        if(scelta == 0)
            inchiostroGiallo = 100;

        return inchiostroGiallo;
    }

    public int InchiostroNero(int utilizzo, int scelta) {
        if(scelta == 1)
            inchiostroNero = inchiostroNero- utilizzo;

        if(scelta == 0)
            inchiostroNero = 100;

        return inchiostroNero;
    }
}