public class Cartuccia {

    private final String colore;
    private double livello;
    public final double capacita;

    public Cartuccia(String colore, double capacita){
        this.colore = colore;
        this.capacita = capacita;
        livello = capacita;
    }

    public String getColore(){
        return colore;
    }

    public double getLivello(){
        return livello;
    }

    public boolean uso() {
        if (livello > 0){
            livello = livello - (capacita / 100);
            return true;
        }else{
            return false;
        }
    }
}
