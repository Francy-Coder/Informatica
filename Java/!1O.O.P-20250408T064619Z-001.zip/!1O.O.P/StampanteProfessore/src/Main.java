/*
 * CLASSI
 *  - Stampante
 *  - cartuccia
 *
 * */

/*
 * color = 1 --> nero
 */

public class Main {
    static Cartuccia[] listaC = new Cartuccia[4];

    public static void stampa(int color){
        if (color == 1) listaC[0].uso();
        else{
            listaC[0].uso();
            listaC[1].uso();
            listaC[2].uso();
            listaC[3].uso();
        }
    }

    public static String stampaLivelli(){
        String s="";
        for(Cartuccia c : listaC){
            s = s + c.getColore()+" livello "+c.getLivello() +"\n";
        }
        return s;
    }

    public static void main(String[] args) {
        /*Cartuccia c = new Cartuccia("Nero", 175);
        for(int i = 0; i < c.capacita+20; i++){
            System.out.println("uso: " +i+ " livello: " +c.getLivello() + " uso?: " +c.uso());
            c.uso();
        }*/

        //Contenitore di cartuccie
        listaC[0] = new Cartuccia("Nera", 500);
        listaC[1] = new Cartuccia("Magenta", 100);
        listaC[2] = new Cartuccia("Giallo", 15);
        listaC[3] = new Cartuccia("Ciano", 25);

        for(Cartuccia c : listaC)
            System.out.println("colore: " +c.getColore() +" livello: " +c.getLivello());


        stampa(1);
        System.out.println(stampaLivelli());
        stampa(2);
        System.out.println(stampaLivelli());
        stampa(3);
        System.out.println(stampaLivelli());
        stampa(4);
        System.out.println(stampaLivelli());
    }
}