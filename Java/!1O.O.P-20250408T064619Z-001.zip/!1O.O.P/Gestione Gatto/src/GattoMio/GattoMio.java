public class GattoMio {
    String coda, coloreOcchi, maschioFemmina, ciboPreferito, odia;
    int zampe;

    //COSTRUTTORE
    public GattoMio(int zampe, String coda, String coloreOcchi, String maschioFemmina, String ciboPreferito, String odia){
        this.zampe = zampe;
        this.coda = coda;
        this.coloreOcchi = coloreOcchi;
        this.maschioFemmina = maschioFemmina;
        this.ciboPreferito = ciboPreferito;
        this.odia = odia;
    }

    public void stampa(){
        System.out.println("zampe " + zampe +
                "\ncoda " + coda +
                "\ncoloreOcchi " + coloreOcchi +
                "\nmaschioFemmina " + maschioFemmina +
                "\nciboPreferito " + ciboPreferito +
                "\nodia " + odia);
    }

}
