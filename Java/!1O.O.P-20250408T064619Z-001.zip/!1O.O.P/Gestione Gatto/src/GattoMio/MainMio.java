public class MainMio {
    public static void main(String[] args) {
        GattoMio uno, due, tre;
        uno = new GattoMio(3, "lunga", "blu",
                "maschio", "croccantini", "cani");
        System.out.println("\nPrimo gatto: ");
        uno.stampa();

        due = new GattoMio(4, "media", "bianchi",
                "femmina", "pesce", "acqua");
        System.out.println("\nSecondo gatto: ");
        due.stampa();

        tre = new GattoMio(4, "piccola", "verdi", "femmina", "carote", "buio");
        System.out.println("\nTerzo gatto:");
        tre.stampa();
    }
}