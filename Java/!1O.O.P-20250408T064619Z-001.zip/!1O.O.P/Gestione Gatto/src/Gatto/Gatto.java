public class Gatto {
    //ATTRIBUTI - CARATTERISTICHE - VARIABILI GLOBALI
    String pelo, razza, colore, nome, cosaFa;
    public int eta; //public e private vanno ha indicare se un attributo è visibile oppure no
                    //private serve per non esspore quello che non deve essere esposto

    //MEDOTI ---> Comportamento, le azioni, funzionalità
    //COSTRUTTORE

    public Gatto(String pelo, String razza, String colore, String nome, String cosaFa, int eta){
        this.pelo = pelo; //Se la variabile locale oscura la variabile globale, si usa "this." per richiamare/usare una variabile globale oscurata
        this.razza = razza;
        this.colore = colore;
        this.nome = nome;
        this.cosaFa = cosaFa;
        this.eta = eta;
    }

    public void stampa(){
        System.out.println("pelo " + pelo +
                "\nrazza " + razza +
                "\ncolore " + colore +
                "\nnome " + nome +
                "\ncosaFa " + cosaFa +
                "\neta " + eta);
    }
}

//Lo scopo di una variabile è di memorizzare un informazione, in cui questa informazione posso utillizarla o posso assegnerarla un valore