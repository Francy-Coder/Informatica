public class Main {
    public static void main(String[] args) {
        //definisco una variabile di tipo Gatto
        Gatto uno;
        //creo il gatto
        uno = new Gatto("lungo", "soriana", "azzurro",
                "briciola", "dorme", 1);
        System.out.println("\ngatto: ");
        uno.stampa();

        //-------------------

        //eta pubblico (public) si può usare età perchè è pubblico (tutte le classi possono usarlo)
        //età privato (private) non si può usare perchè è privato (solo la classe che lo contiene può usarlo)
        System.out.println("\nprivate/public: ");
        uno.eta = 1000;
        System.out.println(uno.eta);

        System.out.println("\nsomma: " + Calcola.somma(3,6));


    }
}
