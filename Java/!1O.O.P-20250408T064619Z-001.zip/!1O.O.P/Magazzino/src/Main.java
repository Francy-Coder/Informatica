/*Consegnare il progetto e il programma in java.

Immagina di avere un assistente personale per gestire il tuo magazzino. Questo assistente, che in realtà è un programma informatico, è in grado di tenere traccia di tutti i prodotti presenti nel magazzino e di gestire gli ordini in modo efficiente.
Come funziona:

- Catalogo prodotti: All'inizio, il programma viene "istruito" con una lista completa dei prodotti presenti nel magazzino. Per ogni prodotto, conosce il nome, il prezzo, un codice identificativo unico e la quantità attualmente disponibile. Questa lista è fissa e può essere modificata solo dal gestore del magazzino.
- Creazione ordini: Quando vuoi effettuare un ordine, il programma ti mostrerà un elenco di tutti i prodotti disponibili. Potrai selezionare i prodotti che desideri e specificarne la quantità. L'assistente si assicurerà che la quantità richiesta sia disponibile in magazzino e calcolerà automaticamente il prezzo totale dell'ordine.
- Gestione scorte: Ogni volta che un prodotto viene aggiunto a un ordine, il programma aggiorna automaticamente la quantità disponibile in magazzino, assicurandosi che non vengano venduti più prodotti di quelli effettivamente presenti.
- Limite ordini: Per evitare di sovraccaricare il sistema, puoi impostare un limite massimo al numero di ordini che possono essere creati.
- Visualizzazione ordini: In qualsiasi momento, puoi richiedere al programma di mostrarti un elenco di tutti gli ordini effettuati, con i dettagli dei prodotti acquistati e il prezzo totale.

Il programma agisce come un vero e proprio magazziniere virtuale, semplificando le operazioni di gestione del magazzino e garantendo la precisione delle informazioni. Grazie a questo strumento, potrai tenere sotto controllo le scorte, gestire gli ordini in modo efficiente e avere sempre una panoramica completa dello stato del tuo magazzino.

Il prodotto è caratterizzato da: nome, prezzo, codice e quantità totale disponibile in magazzino (qta)
Un ordine è caratterizzato da: numero d’ordine, data, lista dei prodotti e il prezzo totale*/

import java.util.Scanner;
public class Main {
    static Prodotto[] listaP = new Prodotto[10];
    static Ordine[] listaE = new Ordine[10];

    public static String stampaProdotti() {
        String s = "";
        s = s + "Elenco dei prodotti:\n";
        for(int i = 0; i <= 9; i++){
            s = s + (i + 1) + ". " + "Nome: " + listaP[i].getNome() + " - Prezzo: " + listaP[i].getPrezzo() + " - Codice: " + listaP[i].getCodice() + " - QTA: " + listaP[i].getQta() + "\n";
        } return s;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String password;
        System.out.println("Inserisci la password: ");
        password = sc.next();

        int condizioneAccount = 1;
        do {
            if (password.equals("segreto")) {
                GestoreMagazzino ge = new GestoreMagazzino();

                System.out.println("Sei nella modalità gestore");


            } else {

                System.out.println("Sei nella modalità utente");

                //la lista di prodotti dovrebbe andare nel gestoreMagazzino
                listaP[0] = new Prodotto("Libro", 11.63, 123, 30);
                listaP[1] = new Prodotto("Calendario", 5.50, 456, 40);
                listaP[2] = new Prodotto("Ciotola", 3.95, 789, 25);
                listaP[3] = new Prodotto("Lampadina", 1.95, 987, 20);
                listaP[4] = new Prodotto("Squadra", 15.99, 654, 15);
                listaP[5] = new Prodotto("Rubrica", 3.80, 321, 30);
                listaP[6] = new Prodotto("Stampante", 59, 135, 10);
                listaP[7] = new Prodotto("Televisione", 303.90, 246, 5);
                listaP[8] = new Prodotto("Accessori per la macchina", 23.99, 790, 10);
                listaP[9] = new Prodotto("Borraccia", 9.99, 680, 20);

                int codizioneUtente = 0;
                do {
                    System.out.println("\nCosa vuoi fare? \n1. Effettua Ordine \n2. Esci");
                    int scelta = sc.nextInt();
                    switch (scelta) {
                        case 1:
                            System.out.println(stampaProdotti());

                            System.out.println("Seleziona il proddoto che si vuole: ");
                            int selezione = sc.nextInt();

                            System.out.println("Seleziona la quantità che si vuole: ");
                            int quantita = sc.nextInt();

                            if (quantita < listaP[selezione].getQta()) {
                                int calcolo = quantita - listaP[selezione].getQta();
                                listaP[selezione].setQta(calcolo);
                                //inserire il numero del ordine + prezzo totale
                            } else {
                                System.out.println("Hai superato la quantita di prodotti disponibili");
                            }
                            break;

                        case 2:
                            codizioneUtente = 1;
                            System.out.println("Arrivederci");
                            break;
                    }
                } while (codizioneUtente != 1);
            }
        } while(condizioneAccount != 1);
    }
}