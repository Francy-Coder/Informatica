/*Un ordine è caratterizzato da:
numero d’ordine, data, lista dei prodotti e il prezzo totale*/

public class Ordine {
    private int nrOrdine;
    private int data;
    private int[] listaProdotti;
    private double prezzoTotale;

    public Ordine(int nrOrdine, int data, int[] listaProdotti, int prezzoTotale){
        this.nrOrdine = nrOrdine;
        this.data = data;
        this.prezzoTotale = prezzoTotale;
    }

    public int getNrOrdine(){
        return nrOrdine;
    }

    public int getData(){
        return data;
    }

    public double getPrezzoTotale(){
        return prezzoTotale;
    }

    public void setListaProdotti(){

    }
}
