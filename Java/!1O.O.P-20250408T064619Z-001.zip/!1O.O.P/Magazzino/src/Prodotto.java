/*Il prodotto è caratterizzato da:
nome, prezzo, codice e quantità totale disponibile in magazzino (qta)*/

public class Prodotto {
    private String nome;
    private double prezzo;
    private int codice;
    private int qta;

    public Prodotto(String nome, double prezzo, int codice, int qta){
        this.nome = nome;
        this.prezzo = prezzo;
        this.codice = codice;
        this.qta = qta;
    }

    public String getNome(){
        return nome;
    }

    public void setNome(){
        this.nome = nome;
    }

    public double getPrezzo(){
        return prezzo;
    }

    public void setPrezzo(){
        this.prezzo = prezzo;
    }

    public int getCodice(){
        return codice;
    }

    public void setCodice(){
        this.codice = codice;
    }

    public int getQta(){
        return qta;
    }

    public void setQta(int calcolo){
        this.qta = qta;
    }
}
