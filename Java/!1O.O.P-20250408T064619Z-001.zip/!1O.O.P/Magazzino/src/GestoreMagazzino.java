public class GestoreMagazzino {
}
