/*Metodi:
- Stampa a video tutti i libri
- Aggiungere Libro
- Rimuovere Libro
- Modificare Libro
- Cercare libro con il codice univoco / Vedere le caratteristiche
*/

public class Scaffale{
    private Libro[] libri = new Libro[100];
    private int numLibri = 0;

    public Scaffale () {
    }

    public void stampa(){
        if (numLibri == 0){
            System.out.println("Lo scaffale è vuoto.");
        }else{
            for (int i = 0; i < numLibri; i++){
                System.out.println("Libro " + (i+1) + ": " + libri[i].titolo);
            }
        }
    }

    public void aggiungiLibro(Libro libro){
        if (numLibri < 100){
            libri[numLibri] = libro;
            numLibri++;
            System.out.println("Il libro è stato aggiunto allo scaffale.");
        }else{
            System.out.println("Lo scaffale è pieno.");
        }
    }

    public void rimuoviLibro(String codice){
        for (int i = 0; i < numLibri; i++){
            if (libri[i].codice.equals(codice)){
                for (int j = i; j < numLibri - 1; j++){
                    libri[j] = libri[j + 1];
                }
                numLibri--;
                System.out.println("Il libro è stato rimosso dallo scaffale.");
                return;
            }
        }
        System.out.println("Il libro non è stato trovato.");
    }

    public void modificaLibro(String codice, String descrizioneModificata, String codiceModificato, int costoModificato){
        for (int i = 0; i < numLibri; i++){
            if (libri[i].titolo.equals(codice)){
                libri[i].descrizione = descrizioneModificata;
                libri[i].codice = codiceModificato;
                libri[i].costo = costoModificato;
                System.out.println("Il libro è stato modificato.");
                return;
            }
        }
        System.out.println("Il libro non è stato trovato.");
    }

    public boolean cercaLibroCodice(String codice){
        for (int i = 0; i < numLibri; i++){
            if (libri[i].codice.equals(codice)){
                System.out.println("Il libro è stato trovato: ");
                System.out.println("Titolo: " + libri[i].titolo);
                System.out.println("Descrizione: " + libri[i].descrizione);
                System.out.println("Codice: " + libri[i].codice);
                System.out.println("Costo: " + libri[i].costo);
                return false;
            }
        }
        System.out.println("Libro non trovato.");
        return false;
    }
}