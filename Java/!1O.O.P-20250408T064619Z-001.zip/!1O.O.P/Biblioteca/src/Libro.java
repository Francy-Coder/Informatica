/*Attributi:
- Titolo
- Descrizione
- Codice (univoco)
- Costo
*/

public class Libro{
    String titolo;
    String descrizione;
    String codice;
    int costo;

    public Libro(String titolo, String descrizione, String codice, int costo){
        this.titolo = titolo;
        this.descrizione = descrizione;
        this.codice = codice;
        this.costo = costo;
    }
}