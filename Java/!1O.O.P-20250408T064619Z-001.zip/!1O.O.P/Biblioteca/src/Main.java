/* Scrivere un programma in Java per la gestione degli scaffali di una biblioteca.
Gli scaffali sono caratterizzati da avere l’elenco dei libri, il nome della categoria e ognuno può contenere al massimo 100 libri. Del libro si conosce il titolo, la descrizione, il codice (univoco), il costo.
Dall scaffale deve essere possibile recuperare l’elenco dei libri e i dati di un libro specificando il codice. Prevedere le funzionalità per modificare e leggere le caratteristiche dei singoli oggetti.
Nel main è richiesto creare un oggetto scaffale e utilizzare le sue funzionalità.
*/

import java.util.Scanner;
public class Main{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Scaffale lb = new Scaffale();

        int scelta, comando = 1;
        String titolo, codiceUnivoco, descrizione, codice;
        int costo;

        do{
            System.out.println("\nCosa vuoi fare? \n1. Elenco dei Libri \n2. Aggiungi un Libro \n3. Rimuovi un Libro \n4. Modifica un Libro \n5. Cerca un libro con il codice univoco \n6. Esci");
            scelta = sc.nextInt();
            switch (scelta){
                case 1:
                    System.out.println("Ecco l'elenco dei libri: ");
                    lb.stampa();
                    break;

                case 2:
                    System.out.println("Inserisci un titolo: ");
                    titolo = sc.next();

                    System.out.println("Inserisci la descrizione: ");
                    descrizione = sc.next();

                    System.out.println("Inserisci un codice univoco: ");
                    codiceUnivoco = sc.next();

                    System.out.println("Inserisci il costo: ");
                    costo = sc.nextInt();
                    Libro nuovoLibro = new Libro(titolo, descrizione, codiceUnivoco, costo);
                    lb.aggiungiLibro(nuovoLibro);
                    break;

                case 3:
                    System.out.print("Inserisci il codice del libro da rimuovere: ");
                    codice = sc.next();
                    lb.rimuoviLibro(codice);
                    break;

                case 4:
                    System.out.print("Inserisci il codice del libro da modificare: ");
                    codice = sc.next();

                    lb.cercaLibroCodice(codice);

                    if (lb.cercaLibroCodice(codice)) {
                        System.out.println("Inserisci un nuovo titolo: ");
                        String nuovoTitolo = sc.nextLine();

                        System.out.println("Inserisci la nuova descrizione: ");
                        String nuovaDescrizione = sc.next();

                        System.out.println("Inserisci un nuovo codice univoco: ");
                        String nuovoCodiceUnivoco = sc.next();

                        System.out.println("Inserisci il nuovo costo: ");
                        int nuovoCosto = sc.nextInt();

                        lb.modificaLibro(nuovoTitolo, nuovaDescrizione, nuovoCodiceUnivoco, nuovoCosto);
                    }else{
                        System.out.println("Il libro non è stato trovato.");
                    }
                    break;

                case 5:
                    System.out.println("\nInserisci il codice univoco del libro da cercare: ");
                    codice = sc.next();
                    lb.cercaLibroCodice(codice);
                    break;

                case 6:
                    comando = 0;
                    System.out.println("\nArrivederci");
                    break;

                default:
                    System.out.println("\nDevi scegliere un numero tra 1 e 7.");
            }
        }while(comando != 0);
    }
}